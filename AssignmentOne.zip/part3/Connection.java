package part3;

    /** 
     * every feature has four connections
     * a connection is a pixel (i.e will have an x and y) and marked as either true or false
     * @author oliviamary-clarecarline
     *
     */
    public class Connection {
        int x;
        int y;
        boolean sign;

        @Override
        public String toString() {
        	if(sign == true){
        		return ("{" + x + ", " + y + ", True}");
        	}
        	return ("{" + x + ", " + y + ", False}");
        }
        Connection(int x, int y, boolean sign) {
            this.x = x;
            this.y = y;
            this.sign = sign;
        }
    }