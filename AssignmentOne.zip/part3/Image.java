package part3;


public class Image {
	/*
     *  to distinguish between two classes of black and white images (X’s and O’s).
     */
    public enum XOClass {
    	
        X ("Yes", 1),
        O ("other", 0);

        private String stringValue;
        public int value;
        XOClass(String stringValue, int value) {
            this.stringValue = stringValue;
            this.value = value;
        }
        public static XOClass fromValue(String value) {
            for(XOClass ic : XOClass.values()) {
                if(ic.stringValue.equals(value)) {
                    return ic;
                }
            }
            return null;
        }
        public static XOClass fromValue(int value) {
            switch(value) {
                default:
                case 0:
                    return O;
                case 1:
                    return X;
            }
        }
    }
	
	
    public boolean data[][];
    public Image.XOClass xoClass;

}