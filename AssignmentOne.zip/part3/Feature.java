package part3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 
 * @author oliviamary-clarecarline
 *
 */
public class Feature {
	private static Random random = new Random(1);
    private double weight;
    private List<Connection> connections = new ArrayList<>();
    
  /**
   * create feature and add connections with random weight and random width, height and boolean
   * @param width
   * @param height
   * @param connectionCount
   */
    public Feature(int width, int height, int connectionCount) {
        for(int a = 0;a < connectionCount;a++) {
            connections.add(new Connection(random.nextInt(width), random.nextInt(height), random.nextBoolean()));
        }
        this.weight = random.nextDouble() * 0.5;
    }


    @Override
    public String toString() {
    	return ("Feature weight: " + weight + "\n " + connections + "\n");
    }
    
    /** 
     * return 1 if at least 3 connections match image pixel, otherwise return 0
     * @param image
     * @return
     */
    double checkFeature(boolean image[][]) {
        int sum = 0;
        for(Connection c : connections) {
            sum += (image[c.x][c.y] == c.sign) ? 1 : 0;
        }
        if(sum >=3 ) return 1;
        return 0;
    }

    public double getWeight() {
        return weight;
    }
    public void updateWeight(double delta) {
        weight -= delta;
    }
}