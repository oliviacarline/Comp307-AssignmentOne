package part3;



import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Perceptron {
    private List<Feature> features;
    private double learningRate = 0.025;
    int correct = 0;
    int incorrect = 0;

    
    public Perceptron(List<Feature> features) {
        this.features = features;
    } 
    
/** 
 * 
 * @param images
 */
    public void train(List<Image> images) {
        int a;
        for(a = 0;a < 1000;a++) {
            int correct = 0;
            for (Image i : images) {
            	//check every feature for every image
                double result = 0;
                for (Feature f : features) {
                    result += f.checkFeature(i.data) * f.getWeight();
                }
                int actual = i.xoClass.value;
                double error = result - actual;
                //if perceptron is correct, do nothing
                if ((result > 0 && actual == 1) || (result <= 0 && actual == 0)) {
                    correct++;
                    continue;
                }
                //if perceptron is wrong, edit feature weight 
                for (Feature f : features) {     
                    f.updateWeight(error * learningRate * f.checkFeature(i.data));
                }
            }
            //train the perceptron on the images until either it has presented the whole set of images at least 100
           // times or the perceptron weights have converged 
            if(correct >= images.size()) {
                System.out.printf("Reached Convergence\n");
                break;
            }
        }
        System.out.printf("Number of training cycles: %d \n", a);
    }
    
    /** 
     * how accurate is the perceptron? 
     * go through all items in list and check if features are correct in image
     * @param images
     */
    public void evaluate(List<Image> images) {
        for (Image image : images) {
            double output = 0;
            int xoClass = image.xoClass.value;
            
            for(Feature feature : features) {
                output += feature.checkFeature(image.data) * feature.getWeight();
            }            
            if ((output > 0 && xoClass == 1) || (output <= 0 && xoClass == 0)) {
                correct++;
            } else {
                incorrect++;
            }
        }
        System.out.printf("Number of correct images: %d out of %d \n \n", correct, (incorrect + correct));
    }
    


    /**
     * Read file and load images, the image files in the data set do not have any comments other than the one on the second 
     * line but the PBM rules allow comments starting with # at any point in the file after the first token. In the image files
     *  in the data set, the pixels have no whitespace between them (other than the line breaks)
     * @param fileName
     * @return
     * @throws FileNotFoundException
     */
    private static List<Image> loadImages(String fileName) throws FileNotFoundException {
        Scanner scan = new Scanner(new File(fileName));
        List<Image> imageList = new ArrayList<>();
        Pattern bit = Pattern.compile("[01]");
        //first line should contain P1
        //second line has class of image, either yes or other
        //third line contains width and height
        //remaining lines have 1's and 0's representing pixels
        while(scan.hasNextLine()) {
            Image image = new Image();
            if (!scan.next().equals("P1")) System.out.println("Not correct file format");
            image.xoClass = Image.XOClass.fromValue(scan.next().substring(1));
            int rows = scan.nextInt();
            int cols = scan.nextInt();
            image.data = new boolean[rows][cols];
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    image.data[r][c] = (scan.findWithinHorizon(bit, 0).equals("1"));
                }
            }
            imageList.add(image);
        }
        scan.close();
        return imageList;
    }
    
    /**
	 * load images from image.data
	 * The program should construct a perceptron that uses at least 50 random features
	 * @param argv
	 * @throws FileNotFoundException
	 */
    public static void main(String[] argv) throws FileNotFoundException {
        List<Image> imageList = loadImages(argv[0]);
        List<Feature> featureList = new ArrayList<>();
        System.out.println("Reading from file " + argv[0] + "\n");
        int numfeature = 80;
        for(int i = 0;i < numfeature;i++) {
            featureList.add(new Feature(10, 10, 4));
        }
        Perceptron p = new Perceptron(featureList);
        p.train(imageList);
        p.evaluate(imageList);
        featureList.forEach(System.out::println);
    }
}


