package part1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class KNN {
	static double size;
	static double accurateCount = 0;
	static Map<Double[], String> fileMap = new HashMap<Double[], String>();
	static Map<Double, String> kNearest;
	static String mostFrequentClass;


/**
 * Iterate through test set and through training set, putting training set into TreeMap
 * @param trainingSet
 * @param testSet
 * @param kValue
 */
private static void iterateTestSet(Map<Double[], String> trainingSet, Map<Double[], String> testSet, int kValue) {
	// Iterate through the test set
	for (Map.Entry<Double[], String> testEntry : testSet.entrySet()) {
		kNearest = new TreeMap<Double, String>();
		double value = 0;
		int theKvalue = kValue;
		Double[] currentArray = testEntry.getKey();

		for (Map.Entry<Double[], String> trainingEntry : trainingSet.entrySet()) {
			value = getDifference(currentArray, trainingEntry.getKey());
			kNearest.put(value, trainingEntry.getValue());
		}
		findFrequent(theKvalue);
		printInstance(testEntry.getValue());
		}
	}



/**
 *find the most frequent class of the neighbours
 * @param theKvalue
 * @param kNearestNeighbours
 */
	private static void findFrequent(int theKvalue) {
		Map<String, Integer> neighbours = new HashMap<String, Integer>();
		double tempValue = 0.0;
		mostFrequentClass = "";
		int count = 0;

		//// Get the first 'k' number of nearest neighbours
		String[] kNeighbours = new String[theKvalue];
		for (Map.Entry<Double, String> entry : kNearest.entrySet()) {
			if (count >= theKvalue)
				break;

			kNeighbours[count] = entry.getValue();
			count++;
		}

		//find the most common class in the set of nearest neighbours
		for (int i = 0; i < theKvalue; i++) {
			String neighbour = kNeighbours[i];
			if (!neighbours.containsKey(kNeighbours[i]))
				neighbours.put(neighbour, 1);
			else
			neighbours.put(neighbour, neighbours.get(neighbour) + 1);
		}

		for (Map.Entry<String, Integer> entry : neighbours.entrySet()) {
			if (entry.getValue() > tempValue) {
				tempValue = entry.getValue();
				mostFrequentClass = entry.getKey();
			}
		}
	}



	/**
	 * Print out results in console, if nearest = actual result than it's been successful
	 * @param name
	 */
	private static void printInstance(String name){
		if(mostFrequentClass.equals(name)){
			System.out.println("Actual: " + name + " VS Predicted: " + mostFrequentClass);
			accurateCount++;
		}
		else
			System.err.println("Actual: " + name + " VS Predicted: " + mostFrequentClass);
	}

	/**
	 * runs through the file to return a map that contains an array of doubles holding
	 * the numerical values of the iris(sepal length, sepal width, petal length,
	 * and petal width that has the value as the class name of the iris
	 * @param file
	 * @return
	 */
	private static Map<Double[], String> fileScan(File file) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(file));
			while (reader.ready()) {
				String[] line = reader.readLine().split("  ");
				// Check if line is valid
				if (line.length < 5)
				break;
			//parse string first four elements in array into double array and add final section as map value
				fileMap.put(new Double[] { Double.parseDouble(line[0]), Double.parseDouble(line[1]),
						Double.parseDouble(line[2]), Double.parseDouble(line[3]) }, line[4]);
			}
			reader.close();
		} catch (NumberFormatException | IOException e) {
			e.printStackTrace();
		}

		return fileMap;
	}

	/**
	 * Get the total difference in the 4 values of iris
	 *
	 * @param test
	 * @param training
	 * @return the distance/difference of the values
	 */
	private static double getDifference(Double[] test, Double[] training) {
		double value = 0;
		for(int i = 0; i < 4; i++)
			value += Math.pow(test[i] - training[i], 2);

		return Math.sqrt(value);
	}

	/**
	 * Main method, takes two file names as command line arguments
	 * asks for kvalue and calls iterateTestSet
	 * @param args
	 */
	public static void main(String[] args) throws FileNotFoundException{
		File setOne = new File(args[0]);                                                    
		File setTwo = new File(args[1]);
		Map<Double[], String> trainingMap = fileScan(setOne);
		Map<Double[], String> testMap = fileScan(setTwo);
		size = testMap.size();

		//scan user input for k value
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter a value for K:");
		int kValue = scan.nextInt();
		scan.close();
		System.out.println();

		iterateTestSet(trainingMap, testMap, kValue);
		System.out.printf("\nAlgorithm Accuracy: %.2f for %.2f instances", (accurateCount / size * 100), size);
	}

}
