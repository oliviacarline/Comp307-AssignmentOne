package part2;

/**
 * 
 * @author oliviamary-clarecarline
 *
 */
public class LeafNode implements Node{
	private String className;
	private double probability;
	
	
	public LeafNode(int className, double probability){
		if(className==0){
			this.className = "live";
		}else this.className = "die";
		this.probability = probability;
	}
	
	
	/**
	 * Taken from the assignment description, For each leaf node, print out the
	 * class name in the leaf node and the fraction. By increasing the indentation
	 * on each recursive call, it becomes somewhat readable.
	 */
	public void report(String indent){
		System.out.format("%sClass %s, prob= %4.2f%n",
		indent, className, probability);
		}


	@Override
	public Node getLeft() {
		return null; }
	@Override
	public Node getRight() {
		return null; }
	@Override
	public String getAttName() {
		return null; }

	
	public int getClassName() {
		int classType;
		if(className.equals("live")){
			return classType = 0;
		}else return classType = 1;
	}


	public void setClassName(String className) {
		this.className = className;
	}

}
