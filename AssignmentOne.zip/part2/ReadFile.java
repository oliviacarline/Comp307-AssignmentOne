package part2;

import java.text.NumberFormat;
import java.util.*;
import java.io.*;

/**
 * 
 * @author oliviamary-clarecarline
 *
 */
public class ReadFile{
	int numCategories;
	int numAtts;
	private List<String> trainingCategoryNames;
	private List<String> trainingAttNames;
	private List<ReadFile.Instance> allTrainingInstances;
	private List<String> testCategoryNames;
	private List<String> testAttNames;
	private List<ReadFile.Instance> allTestInstances;
	private int matched = 0;
	double baseaverage = 0;
	int correctLiveCount = 0;
	int correctDieCount = 0;
	int numTestInsLive = 0;
	int numTestInsDie = 0;


	
	public double evaluate(ReadFile rf, Node node){
		for(int i = 0; i<rf.getAllTestInstances().size(); i++){
			rf.checkTestInstance(rf.getAllTestInstances().get(i),node);
		}
		double accuracy = (double)matched/rf.getAllTestInstances().size();

		for(int j = 0; j<rf.getAllTestInstances().size(); j++){
			if(rf.getAllTestInstances().get(j).getCategory()==0){
				numTestInsLive++;	}
			else if(rf.getAllTestInstances().get(j).getCategory()==1){
				numTestInsDie++;	}

			if(rf.getAllTestInstances().get(j).getPredicted()==rf.getAllTestInstances().get(j).getCategory()
					&& rf.getAllTestInstances().get(j).getCategory()==0){
				correctLiveCount++; }
			else if(rf.getAllTestInstances().get(j).getPredicted()==rf.getAllTestInstances().get(j).getCategory()
					&& rf.getAllTestInstances().get(j).getCategory()==1){
				correctDieCount++;}
		}
		matched = 0;

		//print out the results
		System.out.println("Live: " + correctLiveCount + "  correct out of " + numTestInsLive);
		System.out.println("Die: " + correctDieCount + "  correct out of " + numTestInsDie);
		System.out.println("Accuracy: ");
		System.out.printf("Decision Tree Accuracy: %.2f \n", accuracy);
		baseaverage += (double)numTestInsLive/rf.getAllTestInstances().size();
		System.out.printf("Baseline Accuracy (live):  %.2f \n",  (double)numTestInsLive/rf.getAllTestInstances().size());
		return accuracy;
	}
	
	
	
	/**
	 * taken from helper code
	 * @param fname
	 */
	void readTrainingDataFile(String fname){
		System.out.println("Reading data from file "+fname);
		try {
			Scanner din = new Scanner(new File(fname));
			trainingCategoryNames = new ArrayList<String>();
			for (Scanner s = new Scanner(din.nextLine()); s.hasNext();) trainingCategoryNames.add(s.next());
			numCategories=trainingCategoryNames.size();
			trainingAttNames = new ArrayList<String>();
			for (Scanner s = new Scanner(din.nextLine()); s.hasNext();) trainingAttNames.add(s.next());
			numAtts = trainingAttNames.size();
			allTrainingInstances = readInstances(din);
			din.close();}
		catch (IOException e) {
			throw new RuntimeException("Data training File caused IO exception");
		}}
	void readTestDataFile(String fname){
		System.out.println("Reading data from file "+fname);
		try {
			Scanner din = new Scanner(new File(fname));
			testCategoryNames = new ArrayList<String>();
			for (Scanner s = new Scanner(din.nextLine()); s.hasNext();) testCategoryNames.add(s.next());
			numCategories=testCategoryNames.size();
			testAttNames = new ArrayList<String>();
			for (Scanner s = new Scanner(din.nextLine()); s.hasNext();) testAttNames.add(s.next());
			numAtts = testAttNames.size();

			allTestInstances = readInstances(din);
			din.close();
		}
		catch (IOException e) {
			throw new RuntimeException("Data test File caused IO exception");
		}
	}
	

	
	
	/**
	 * recursive method check
	 * @param instance
	 * @param root
	 */
	private void checkTestInstance(Instance instance, Node root) {

		if(root instanceof LeafNode && root.getClassName()== instance.getCategory()){
			instance.setPredicted(root.getClassName());
			matched++;
		}
		if(root instanceof NonLeafNode){
			for(int i = 0; i<testAttNames.size(); i++){
				if(testAttNames.get(i).equals(root.getAttName())){
					if(instance.getAtt(i)){
						checkTestInstance (instance, root.getLeft());
					}else{
						checkTestInstance (instance, root.getRight());
						}	}	}	}	}

	
	/**
	 * taken from helper code
	 * @param din
	 * @return
	 */
	private List<ReadFile.Instance> readInstances(Scanner din){
		/* instance = classname and space separated attribute values */
		List<ReadFile.Instance> instances = new ArrayList<ReadFile.Instance>();
		while (din.hasNext()){
			Scanner line = new Scanner(din.nextLine());
			instances.add(new Instance(trainingCategoryNames.indexOf(line.next()),line));
		}
		return instances;
	}
	
	public ReadFile(){
	}
	public int getMatched() {
		return matched;
	}
	public void setMatched(int matched) {
		this.matched = matched;
	}
	public List<ReadFile.Instance> getAllTrainingInstances() {
		return allTrainingInstances;
	}
	public List<String> getTrainingAttNames() {
		return trainingAttNames;
	}
	public List<ReadFile.Instance> getAllTestInstances() {
		return allTestInstances;
	}
	public List<String> getTestAttNames() {
		return testAttNames;
	}
	
/**
 * taken from helper code
 * @author oliviamary-clarecarline
 *
 */
	class Instance {
		private int category;
		private List<Boolean> vals;
		private int predicted = -1;

		public Instance(int cat, Scanner s){
			category = cat;
			vals = new ArrayList<Boolean>();
			while (s.hasNextBoolean()) vals.add(s.nextBoolean());
		}

		public boolean getAtt(int index){
			return vals.get(index);	}
		public int getCategory(){
			return category;	}
		public int getPredicted() {
			return predicted;	}
		public void setPredicted(int predicted) {
			this.predicted = predicted;	}


}
}


