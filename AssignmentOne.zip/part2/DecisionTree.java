package part2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import part2.ReadFile.Instance;

/**
 * 
 * @author oliviamary-clarecarline
 *
 */
public class DecisionTree {
	private List<ReadFile.Instance>allInstances;
	private List<String>allAttrs;


	public DecisionTree(List<ReadFile.Instance>allInstances, List<String>allAttrs){
		this.allInstances = allInstances;
		this.allAttrs =  new ArrayList<String>(allAttrs);
	}

	
	
	public Node buildTree(List<ReadFile.Instance>instances, List<String>attributes){
		List<ReadFile.Instance>bestTrue = new ArrayList<ReadFile.Instance>();
		List<ReadFile.Instance>bestFalse = new ArrayList<ReadFile.Instance>();
		String bestAttribute = "";
		double impurity = 2;	
		
		//if instances is empty, return a lead node containing the name and probability of the overall
		//most probable class (ie, the ‘‘baseline’’ predictor)
		if(instances.size()==0) {
			int liveInstances = liveCount(allInstances);
			int deadInstances = allInstances.size() - liveInstances;
			if(liveInstances>=deadInstances){
				return new LeafNode(0, (double)liveInstances/allInstances.size());
			}else{
				return new LeafNode(1, (double)deadInstances/allInstances.size());
			}
		}
		
		//if instances are pure return a leaf node containing the name of the class of the instances
		//in the node and probability 1
		if(isPure(instances)){
			return new LeafNode(instances.get(0).getCategory(),1);
		}
		
		//if attributes is empty return a leaf node containing the name and probability of the
		//majority class of the i
		if(attributes.size()==0){
			return new LeafNode(majorityClass(instances), majorityProb(instances));
		}
		//else find best attribute
		else{
			//seperate instances into true or false
			for(String attribute: attributes){
				List<ReadFile.Instance>trueInstances = new ArrayList<ReadFile.Instance>();
				List<ReadFile.Instance>falseInstances = new ArrayList<ReadFile.Instance>();

				for(ReadFile.Instance instance: instances){			
					if(instance.getAtt(allAttrs.indexOf(attribute))){
						trueInstances.add(instance);	}
					else if(!instance.getAtt(allAttrs.indexOf(attribute))){
						falseInstances.add(instance);	}
				}

				//check purity of each set, if purity is the best so far, change best variables to match
				double checkImpurity = calculatePurity(trueInstances,falseInstances);
				if(checkImpurity<impurity && checkImpurity!=-1){
					impurity = checkImpurity;
					bestAttribute = attribute;
					bestTrue = trueInstances;
					bestFalse = falseInstances;
				}
			}
			for(int a = 0; a<attributes.size(); a++){
				if(attributes.get(a).equals(bestAttribute)){
					attributes.remove(a);
				}
			}

			//build subtree using the remaining attributes
			List<String> newAttrs = new ArrayList<String>(attributes);
			Node left = buildTree(bestTrue, newAttrs);
			Node right = buildTree(bestFalse, newAttrs);
			return new NonLeafNode(bestAttribute, left, right); 
		}	
	}

	
	
	/**
	 * return greatest probability 
	 * @param instances
	 * @return
	 */
	private double majorityProb(List<ReadFile.Instance> instances) {
		int majority = 0;
		for(int i = 0; i<instances.size(); i++){
			if(instances.get(i).getCategory()==0)
				majority++;
		}
		if(majority>(double)instances.size()/2)
			return (double)majority/instances.size();
		else if(majority<(double)instances.size()/2)
			return 1 - (double)majority/instances.size();
		else return 0.5;
	}

	/**
	 * return which class is greater
	 * @param instances
	 * @return
	 */
	private int majorityClass(List<ReadFile.Instance> instances) {
		int majority = 0;
		for(int i = 0; i<instances.size(); i++){
			if(instances.get(i).getCategory()==0)
				majority++;
		}
		if(majority<(double)instances.size()/2)
			return 1;
		else if(majority>(double)instances.size()/2)
			return 0;
		return (int)(Math.random() * 2);
	}
	
	
	

	private boolean isPure(List<ReadFile.Instance> instances) {
		for(int i = 1; i<instances.size(); i++){
			if(instances.get(i-1).getCategory()!=instances.get(i).getCategory()){
				return false;	} }
		return true;
	}

	private double calculatePurity(List<ReadFile.Instance> trueIns, List<ReadFile.Instance> falseIns) {
		int totalSize = trueIns.size()+falseIns.size();
		int numTrueLiveClass = liveCount(trueIns);
		int numTrueDieClass = trueIns.size()-numTrueLiveClass;
		int numFalseLiveClass = liveCount(falseIns);
		int numFalseDieClass = falseIns.size() - numFalseLiveClass;
		if(trueIns.isEmpty()||falseIns.isEmpty()){
			return -1;
		}
		return ((double)trueIns.size()/totalSize)*(((double)numTrueLiveClass/trueIns.size())*((double)numTrueDieClass/trueIns.size()))
				+ ((double)falseIns.size()/totalSize)*(((double)numFalseLiveClass/falseIns.size())*((double)numFalseDieClass/falseIns.size()));
	}

	private int liveCount(List<ReadFile.Instance>instance){
		int num = 0;
		for(int i = 0; i<instance.size(); i++){
			if(instance.get(i).getCategory()==0) num++;
		}
		return num;
	}

	/**
	 * method used for running the ten tests to calculate average
	 * @param rf
	 */
		public static void tenTests(ReadFile rf) {
					
			String[]index = {"01", "02", "03", "04", "05","06","07","08","09","10"};
			List<Double>accuracys = new ArrayList<Double>();
			NumberFormat defaultFormat = NumberFormat.getPercentInstance();
			for(int add = 0; add<10; add++){
				rf.setMatched(0);
				//read the files and create the 10 tests
				rf.readTrainingDataFile("data/hepatitis-training-run"+index[add]+".dat");
				rf.readTestDataFile("data/hepatitis-test-run"+index[add]+".dat");
				DecisionTree dt = new DecisionTree(rf.getAllTrainingInstances(), rf.getTrainingAttNames());
				Node node = dt.buildTree(rf.getAllTrainingInstances(), rf.getTrainingAttNames());
				double accuracy = rf.evaluate(rf, node);

				System.out.println("----------------------------------------------------");
				accuracys.add(accuracy);
			}
			double total = 0;
			for(double accur: accuracys){
				total +=accur;
			}
			double average =  (double)total/accuracys.size();
			System.out.println("average accuracy of the classifiers over the 10 trials: "+defaultFormat.format(average));
		}
	

	/**
	 * arguments like: hepatitis-training.dat hepatitis-test.dat) in folder outside of src
	 * if no argument, run ten tests otherwise use the parameters to train on files
	 * @param args
	 * @throws FileNotFoundException
	 */
public static void main(String[] args) throws FileNotFoundException{
	ReadFile rf = new ReadFile();
	rf.setMatched(0);
	String trainingAdd = null;
	String testAdd = null;

	if(args.length < 1){
		tenTests(new ReadFile());
	} else {
		trainingAdd = args[0];
		testAdd = args[1];
		rf.readTrainingDataFile(trainingAdd);
		rf.readTestDataFile(testAdd);
		DecisionTree dt = new DecisionTree(rf.getAllTrainingInstances(), rf.getTrainingAttNames());
		Node node = dt.buildTree(rf.getAllTrainingInstances(), rf.getTrainingAttNames());
		rf.evaluate(rf, node);
		node.report("\t");
		
	}
}
}


