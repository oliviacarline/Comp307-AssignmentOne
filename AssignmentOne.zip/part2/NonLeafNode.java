package part2;

/**
 * 
 * @author oliviamary-clarecarline
 *
 */
public class NonLeafNode implements Node{
private String attName;
private Node left;
private Node right;

public NonLeafNode(String attName, Node left, Node right){
	this.attName = attName;
	this.left = left;
	this.right = right;
	
}

/**
 * Taken from the assignment description, The easiest way of outputting the tree is to 
 * do a traversal of the tree. For each non-leaf node, print out the
 * name of the attribute, then print the left tree, then print the right tree. 	
 */
public void report(String indent){
	System.out.format("%s%s = True:\n",
	indent, attName);
	left.report(indent+"   ");
	System.out.format("%s%s = False:\n",
	indent, attName);
	right.report(indent+"   ");
	}
	
@Override
public int getClassName() {
	return -1; }
public Node getLeft() {
	return left; }
public void setLeft(NonLeafNode left) {
	this.left = left; }
public Node getRight() {
	return right; }
public void setRight(NonLeafNode right) {
	this.right = right; }
public String getAttName() {
	return attName; }
public void setAttName(String attName) {
	this.attName = attName; }

}
 